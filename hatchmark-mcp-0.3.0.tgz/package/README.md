# hatchmark-mcp

An MCP server for ISO 24896-aligned business charts. It gives an AI assistant
four tools:

| Tool | What it does |
| --- | --- |
| `list_chart_types` | Every chart and table type, with guidance on when each is the right choice |
| `get_notation` | The scenario, colour and variance rules, with the clause each comes from |
| `render_chart` | Takes your data, returns a finished SVG that already follows the notation |
| `lint_chart` | Checks a chart configuration against the rules and cites what it flags |

It runs locally over stdio. Your data never leaves your machine.

## Install

Download `hatchmark-mcp-<version>.tgz` from
[hatchmark.studio/ai](https://hatchmark.studio/ai), then:

```bash
npm install -g ./hatchmark-mcp-0.3.0.tgz
claude mcp add hatchmark -- hatchmark-mcp
```

Requires Node 20 or newer. For clients other than Claude Code, point the
client at the `hatchmark-mcp` command over stdio.

## What it carries

The package is self-contained: it embeds a snapshot of the hatchmark notation
registry, so it needs no network access and no other repository. Every
response reports the `registry_version` it was built from, so you always know
which edition of the notation produced a chart.

## Building it

```bash
npm run bundle    # embed the registry snapshot, then bundle to dist/
npm run pack:dist # the above, then npm pack
npm run check     # typecheck, tests, and a fresh bundle
```

`npm run embed` reads the registry pinned in `devDependencies` and writes
`src/registry.gen.ts`. To ship a newer notation edition, bump that pin and
rebuild — a test fails if the embedded snapshot and the pin disagree.

---

Not affiliated with, endorsed by, or certified by the IBCS Association or ISO;
references to the standards are descriptive.
